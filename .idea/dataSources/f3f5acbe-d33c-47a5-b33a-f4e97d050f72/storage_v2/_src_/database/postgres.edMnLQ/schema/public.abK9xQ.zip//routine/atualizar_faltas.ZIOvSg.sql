create function atualizar_faltas() returns void
    language plpgsql
as
$$
BEGIN
    -- Soma as presenças FALSE para cada usuário e adiciona à coluna de faltas
    UPDATE usuarios u
    SET faltas = (
        SELECT COUNT(*)
        FROM arranchamentos a
        INNER JOIN refeicoes r
        ON a.refeicao_id = r.id
        WHERE a.usuario_id = u.id
        AND a.presenca = FALSE
        AND r.data <= CURRENT_DATE  -- Considera apenas os registros até o presente dia
    );
END;
$$;

alter function atualizar_faltas() owner to postgres;

